﻿namespace SnakeGame
{
    public enum GridValue
    {
        Empty,
        Snake,
        Food,
        Outside
    }
}
